const welcomeMessage = `Welcome to the Dialogue Baazigar! Are you ready for challenging Dialogue?`;
const startQuizMessage = `OK.  I will ask you 10 Dialogues about bollywood movies. `;
const exitSkillMessage = `Thank you for playing Dialogue Baazigar!  Let's play again soon!`;
const repromptSpeech = `Which other state or capital would you like to know about?`;
const helpMessage = `I know lots of things about the United States.  You can ask me about a state or a capital, and I'll tell you what I know.  You can also test your knowledge by asking me to start a quiz.  What would you like to do?`;
